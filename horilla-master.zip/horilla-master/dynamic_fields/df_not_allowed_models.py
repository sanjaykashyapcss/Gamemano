"""
dynamic_fields/df_not_allowed_models.py
"""

DF_NOT_ALLOWED_MODELS = []

"""
This module contains test cases for the assets application.
"""

from django.test import TestCase
